const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.panel');

tabs.forEach((t) =>
  t.addEventListener('click', () => {
    tabs.forEach((x) => x.classList.remove('active'));
    panels.forEach((p) => p.classList.remove('active'));
    t.classList.add('active');
    document.getElementById(t.dataset.panel).classList.add('active');
  })
);

async function callAI(mode, text) {
  const res = await fetch('/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mode, text }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Request failed.');
  }
  return data.result;
}

async function runAI({ mode, btn, loading, output, input, emptyMsg }) {
  const text = input.value;
  if (!text || !text.trim()) {
    output.textContent = emptyMsg;
    return;
  }
  btn.disabled = true;
  loading.style.display = 'flex';
  output.textContent = '';
  try {
    output.textContent = await callAI(mode, text);
  } catch (err) {
    output.textContent = `Something went wrong: ${err.message}`;
  } finally {
    btn.disabled = false;
    loading.style.display = 'none';
  }
}

// Ask AI
document.getElementById('askBtn').addEventListener('click', () => {
  runAI({
    mode: 'ask',
    btn: document.getElementById('askBtn'),
    loading: document.getElementById('askLoading'),
    output: document.getElementById('askOutput'),
    input: document.getElementById('askInput'),
    emptyMsg: 'Type a question first.',
  });
});
document.getElementById('askClear').addEventListener('click', () => {
  document.getElementById('askInput').value = '';
  document.getElementById('askOutput').textContent = '';
});

// Smart Notes
document.getElementById('notesBtn').addEventListener('click', () => {
  runAI({
    mode: 'notes',
    btn: document.getElementById('notesBtn'),
    loading: document.getElementById('notesLoading'),
    output: document.getElementById('notesOutput'),
    input: document.getElementById('notesInput'),
    emptyMsg: 'Enter a topic to summarize first.',
  });
});
document.getElementById('notesClear').addEventListener('click', () => {
  document.getElementById('notesInput').value = '';
  document.getElementById('notesOutput').textContent = '';
});

// Exam Prep
document.getElementById('examBtn').addEventListener('click', () => {
  runAI({
    mode: 'exam',
    btn: document.getElementById('examBtn'),
    loading: document.getElementById('examLoading'),
    output: document.getElementById('examOutput'),
    input: document.getElementById('examInput'),
    emptyMsg: 'Enter a topic to generate questions for first.',
  });
});
document.getElementById('examClear').addEventListener('click', () => {
  document.getElementById('examInput').value = '';
  document.getElementById('examOutput').textContent = '';
});

// Subjects
const SUBJECTS = [
  { ic: '💻', name: 'Computer Science', hint: 'Explain Data Structures with real-world examples' },
  { ic: '🤖', name: 'AI & ML', hint: 'Explain Artificial Intelligence in simple words' },
  { ic: '➗', name: 'Mathematics', hint: 'Explain eigenvalues and eigenvectors simply' },
  { ic: '🌐', name: 'Networking', hint: 'Explain how the TCP/IP model works' },
  { ic: '⚙️', name: 'Compiler Design', hint: 'Explain the phases of a compiler' },
  { ic: '🗄️', name: 'Databases', hint: 'Explain normalization in DBMS with an example' },
];

const grid = document.getElementById('subjectGrid');
SUBJECTS.forEach((s) => {
  const b = document.createElement('button');
  b.className = 'subject';
  b.innerHTML = `<span class="ic">${s.ic}</span>${s.name}<small>${s.hint}</small>`;
  b.addEventListener('click', () => {
    tabs.forEach((x) => x.classList.remove('active'));
    panels.forEach((p) => p.classList.remove('active'));
    document.querySelector('.tab[data-panel="ask"]').classList.add('active');
    document.getElementById('ask').classList.add('active');
    const askInput = document.getElementById('askInput');
    askInput.value = s.hint;
    askInput.focus();
  });
  grid.appendChild(b);
});
